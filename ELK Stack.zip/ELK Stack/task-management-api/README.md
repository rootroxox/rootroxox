# Task Management API with ELK Stack Integration

A comprehensive Spring Boot REST API demonstrating clean architecture, structured logging, and ELK stack integration for log visualization and monitoring.

## 📋 Table of Contents

- [Overview](#overview)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [API Endpoints](#api-endpoints)
- [ELK Stack Setup](#elk-stack-setup)
- [Logging Architecture](#logging-architecture)
- [Kibana Guide](#kibana-guide)
- [Testing the API](#testing-the-api)

---

## Overview

This project is a Task Management API that allows users to:
- Create, update, and delete users
- Create, update, and delete tasks
- Assign tasks to users
- Filter tasks by status, date, and user
- Track overdue tasks

The application features **structured JSON logging** that integrates with the **ELK stack** (Elasticsearch, Logstash, Kibana) for powerful log searching and visualization.

---

## Technology Stack

| Component | Technology |
|-----------|------------|
| Language | Java 17 |
| Framework | Spring Boot 3.2.0 |
| Build Tool | Maven |
| Database | H2 (dev) / PostgreSQL (prod) |
| ORM | Spring Data JPA / Hibernate |
| Logging | Logback + logstash-logback-encoder |
| Monitoring | Spring Boot Actuator |
| Log Pipeline | Logstash |
| Log Storage | Elasticsearch |
| Visualization | Kibana |

---

## Project Structure

```
task-management-api/
├── pom.xml                          # Maven configuration
├── README.md                        # This file
├── elk-config/                      # ELK configuration files
│   └── logstash/
│       ├── logstash.yml             # Logstash main config
│       └── pipeline/
│           └── task-management.conf # Logstash pipeline
├── scripts/                         # Windows setup scripts
│   ├── setup-elk.bat
│   ├── configure-elk.bat
│   ├── start-elk.bat
│   └── stop-elk.bat
└── src/
    └── main/
        ├── java/com/example/taskmanagement/
        │   ├── TaskManagementApplication.java
        │   ├── controller/          # REST endpoints
        │   │   ├── UserController.java
        │   │   └── TaskController.java
        │   ├── service/             # Business logic
        │   │   ├── UserService.java
        │   │   ├── UserServiceImpl.java
        │   │   ├── TaskService.java
        │   │   └── TaskServiceImpl.java
        │   ├── repository/          # Data access
        │   │   ├── UserRepository.java
        │   │   └── TaskRepository.java
        │   ├── entity/              # JPA entities
        │   │   ├── User.java
        │   │   ├── Task.java
        │   │   └── TaskStatus.java
        │   ├── dto/                 # Data transfer objects
        │   │   ├── user/
        │   │   └── task/
        │   ├── mapper/              # Entity <-> DTO conversion
        │   │   ├── UserMapper.java
        │   │   └── TaskMapper.java
        │   ├── exception/           # Error handling
        │   │   ├── GlobalExceptionHandler.java
        │   │   ├── ErrorResponse.java
        │   │   └── ...
        │   └── filter/              # Request filters
        │       ├── CorrelationIdFilter.java
        │       └── RequestResponseLoggingFilter.java
        └── resources/
            ├── application.yml      # App configuration
            └── logback-spring.xml   # Logging configuration
```

---

## Prerequisites

Before running the application, ensure you have:

1. **Java 17 or higher**
   ```bash
   java -version
   # Should show: openjdk version "17.x.x" or higher
   ```

2. **Maven 3.8+**
   ```bash
   mvn -version
   # Should show: Apache Maven 3.8.x or higher
   ```

3. **For ELK Stack** (optional but recommended):
   - At least 4GB RAM available
   - Elasticsearch 8.11.0
   - Logstash 8.11.0
   - Kibana 8.11.0

---

## Quick Start

### 1. Clone and Build

```bash
cd "c:\Users\ayber\Masaüstü\ELK Stack\task-management-api"

# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

### 2. Verify It's Running

- **Application**: http://localhost:8080
- **Health Check**: http://localhost:8080/actuator/health
- **H2 Console**: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:mem:taskdb`
  - Username: `sa`
  - Password: (empty)

### 3. Test the API

```bash
# Create a user
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "John Doe", "email": "john@example.com"}'

# Create a task
curl -X POST http://localhost:8080/api/tasks \
  -H "Content-Type: application/json" \
  -d '{"title": "Complete project", "description": "Finish Spring Boot project", "userId": 1, "dueDate": "2024-12-31"}'

# Get all tasks
curl http://localhost:8080/api/tasks
```

---

## API Endpoints

### Users

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/users` | Create a new user |
| GET | `/api/users` | Get all users |
| GET | `/api/users/{id}` | Get user by ID |
| GET | `/api/users/email/{email}` | Get user by email |
| PUT | `/api/users/{id}` | Update user |
| DELETE | `/api/users/{id}` | Delete user |

### Tasks

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/tasks` | Create a new task |
| GET | `/api/tasks` | Get all tasks (with optional filters) |
| GET | `/api/tasks/{id}` | Get task by ID |
| GET | `/api/tasks/user/{userId}` | Get tasks by user |
| GET | `/api/tasks/overdue` | Get overdue tasks |
| PUT | `/api/tasks/{id}` | Update task |
| PATCH | `/api/tasks/{id}` | Partial update |
| PATCH | `/api/tasks/{id}/status` | Update task status |
| DELETE | `/api/tasks/{id}` | Delete task |

### Query Parameters for `/api/tasks`

| Parameter | Type | Description |
|-----------|------|-------------|
| `userId` | Long | Filter by user ID |
| `status` | String | Filter by status (PENDING, IN_PROGRESS, COMPLETED, CANCELLED) |
| `fromDate` | Date | Filter by due date from (ISO format: 2024-01-01) |
| `toDate` | Date | Filter by due date to |

---

## ELK Stack Setup

### Native Windows Installation

1. **Download ELK Components**

   Download version 8.11.0 from https://www.elastic.co/downloads/:
   - Elasticsearch: elasticsearch-8.11.0-windows-x86_64.zip
   - Logstash: logstash-8.11.0-windows-x86_64.zip
   - Kibana: kibana-8.11.0-windows-x86_64.zip

2. **Extract to C:\ELK**

   ```
   C:\ELK\
   ├── elasticsearch-8.11.0\
   ├── logstash-8.11.0\
   └── kibana-8.11.0\
   ```

3. **Configure ELK**

   Run the configuration script:
   ```bash
   cd scripts
   configure-elk.bat
   ```

4. **Start ELK**

   ```bash
   start-elk.bat
   ```

5. **Verify Services**

   - Elasticsearch: http://localhost:9200 (should return JSON)
   - Kibana: http://localhost:5601 (web interface)
   - Logstash: listening on TCP port 5044

### Enable ELK Profile in Spring Boot

To send logs directly to Logstash, run with the `elk` profile:

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=elk
```

Or set in application.yml:
```yaml
spring:
  profiles:
    active: elk
```

---

## Logging Architecture

### Log Flow

```
┌─────────────────┐     ┌──────────────┐     ┌───────────────┐     ┌────────┐
│  Spring Boot    │────>│   Logstash   │────>│ Elasticsearch │────>│ Kibana │
│  Application    │     │  (TCP:5044)  │     │  (:9200)      │     │(:5601) │
└─────────────────┘     └──────────────┘     └───────────────┘     └────────┘
        │
        └──> logs/task-management-api.json (file backup)
```

### Correlation ID

Every request gets a unique **Correlation ID** that appears in all related logs:

```
[abc12345] REST request to create task: 'Buy groceries'
[abc12345] Creating new task for user ID: 1
[abc12345] Successfully created task with ID: 5
[abc12345] <== POST /api/tasks | Status: 201 Created | Duration: 45ms
```

In Kibana, search for `correlationId: "abc12345"` to see all logs for a single request.

### Log Levels

| Level | Usage |
|-------|-------|
| DEBUG | Detailed debugging info (development) |
| INFO | Normal operation milestones |
| WARN | Potential issues (not found, validation) |
| ERROR | Errors requiring attention |

### JSON Log Format

Logs are written as JSON for easy parsing:

```json
{
  "@timestamp": "2024-01-15T14:30:45.123Z",
  "level": "INFO",
  "logger_name": "c.e.t.service.TaskServiceImpl",
  "message": "Successfully created task with ID: 5",
  "correlationId": "abc12345",
  "httpMethod": "POST",
  "requestUri": "/api/tasks",
  "application": "task-management-api"
}
```

---

## Kibana Guide

### Creating an Index Pattern

1. Open Kibana: http://localhost:5601
2. Go to **Stack Management** → **Index Patterns**
3. Click **Create index pattern**
4. Enter pattern: `task-management-logs-*`
5. Select `@timestamp` as the time field
6. Click **Create index pattern**

### Searching Logs

In **Discover**:

```
# Find all logs for a specific request
correlationId: "abc12345"

# Find all errors
level: "ERROR"

# Find logs for a specific endpoint
requestUri: "/api/tasks"

# Find slow requests (>100ms)
durationMs: >100

# Combine queries
level: "ERROR" AND requestUri: "/api/users"
```

### Creating a Dashboard

1. Go to **Dashboard** → **Create dashboard**
2. Add visualizations:
   - **Log count by level** (Pie chart)
   - **Requests over time** (Line chart)
   - **Average response time** (Metric)
   - **Error rate** (Gauge)
   - **Top endpoints** (Bar chart)

### Sample Visualizations

**Requests by Status Category:**
- Field: `http_status_category`
- Type: Pie chart

**Response Time Over Time:**
- Y-axis: Average of `durationMs`
- X-axis: @timestamp (Date histogram)

---

## Testing the API

### Using cURL

```bash
# Create a user
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice Smith", "email": "alice@example.com"}'

# Create a task for the user
curl -X POST http://localhost:8080/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Learn Spring Boot",
    "description": "Complete the Spring Boot tutorial",
    "userId": 1,
    "dueDate": "2024-12-31"
  }'

# Update task status to completed
curl -X PATCH http://localhost:8080/api/tasks/1/status \
  -H "Content-Type: application/json" \
  -d '{"status": "COMPLETED"}'

# Get filtered tasks
curl "http://localhost:8080/api/tasks?status=PENDING&userId=1"

# Get overdue tasks
curl http://localhost:8080/api/tasks/overdue
```

### Using PowerShell

```powershell
# Create a user
Invoke-RestMethod -Uri "http://localhost:8080/api/users" `
  -Method POST `
  -ContentType "application/json" `
  -Body '{"name": "Bob Wilson", "email": "bob@example.com"}'

# Get all tasks
Invoke-RestMethod -Uri "http://localhost:8080/api/tasks"
```

---

## Production Considerations

1. **Enable Security** in Elasticsearch and Kibana
2. **Use PostgreSQL** instead of H2
3. **Set appropriate log levels** (INFO for most, WARN for verbose loggers)
4. **Configure proper JVM memory** for ELK components
5. **Set up log rotation** to prevent disk filling
6. **Use HTTPS** for all services
7. **Create backups** of Elasticsearch indices

---

## Troubleshooting

### Application won't start

1. Check if port 8080 is available
2. Verify Java version: `java -version`
3. Check logs in console or `logs/` directory

### Logs not appearing in Kibana

1. Verify Elasticsearch is running: `curl http://localhost:9200`
2. Verify Logstash is running and connected
3. Check if logs are being written to the JSON file
4. Verify the index pattern in Kibana matches your log index name

### Connection refused to Logstash

1. Ensure Logstash is running
2. Check if TCP port 5044 is open
3. Verify the application is using the `elk` profile

---

## License

This project is for educational purposes.

---

## Author

Created as a learning project for Spring Boot and ELK stack integration.
