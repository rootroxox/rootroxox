package com.example.taskmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the Task Management API.
 * 
 * @SpringBootApplication is a convenience annotation that combines:
 * - @Configuration: Marks this class as a source of bean definitions
 * - @EnableAutoConfiguration: Tells Spring Boot to auto-configure based on dependencies
 * - @ComponentScan: Scans for components in this package and sub-packages
 * 
 * When you run this class, Spring Boot will:
 * 1. Start an embedded Tomcat server
 * 2. Configure Spring MVC for REST endpoints
 * 3. Set up JPA and connect to the database
 * 4. Initialize Logback for logging
 */
@SpringBootApplication
public class TaskManagementApplication {

    public static void main(String[] args) {
        // SpringApplication.run() bootstraps the application
        // It creates the ApplicationContext and starts the embedded server
        SpringApplication.run(TaskManagementApplication.class, args);
    }
}
