package com.example.taskmanagement.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.net.InetAddress;

import static net.logstash.logback.argument.StructuredArguments.kv;

/**
 * Logs a clear "Application Ready" message when the app starts successfully.
 * This message will appear in Kibana with logCategory: STARTUP
 */
@Component
public class StartupLogger {

    private static final Logger log = LoggerFactory.getLogger(StartupLogger.class);

    private final Environment environment;

    @Value("${spring.application.name:task-management-api}")
    private String appName;

    @Value("${server.port:8080}")
    private String port;

    public StartupLogger(Environment environment) {
        this.environment = environment;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        String host = "localhost";
        try {
            host = InetAddress.getLocalHost().getHostName();
        } catch (Exception ignored) {
        }

        String[] profiles = environment.getActiveProfiles();
        String activeProfile = profiles.length > 0 ? String.join(",", profiles) : "default";

        log.info("=== APPLICATION READY === {} is running on http://{}:{} with profile '{}'",
                appName, host, port, activeProfile,
                kv("logCategory", "STARTUP"),
                kv("event", "APPLICATION_READY"),
                kv("appName", appName),
                kv("port", port),
                kv("profile", activeProfile));
    }
}
