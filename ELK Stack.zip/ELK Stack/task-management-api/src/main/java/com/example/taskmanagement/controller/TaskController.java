package com.example.taskmanagement.controller;

import com.example.taskmanagement.dto.task.TaskCreateRequest;
import com.example.taskmanagement.dto.task.TaskResponse;
import com.example.taskmanagement.dto.task.TaskStatusUpdateRequest;
import com.example.taskmanagement.dto.task.TaskUpdateRequest;
import com.example.taskmanagement.entity.TaskStatus;
import com.example.taskmanagement.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * REST Controller for Task operations.
 * No logging here - all API logging is done by the filter.
 */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

        private final TaskService taskService;

        public TaskController(TaskService taskService) {
                this.taskService = taskService;
        }

        @PostMapping
        public ResponseEntity<TaskResponse> createTask(@Valid @RequestBody TaskCreateRequest request) {
                TaskResponse response = taskService.createTask(request);
                return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }

        @GetMapping("/{id}")
        public ResponseEntity<TaskResponse> getTaskById(@PathVariable Long id) {
                return ResponseEntity.ok(taskService.getTaskById(id));
        }

        @GetMapping
        public ResponseEntity<List<TaskResponse>> getAllTasks(
                        @RequestParam(required = false) Long userId,
                        @RequestParam(required = false) TaskStatus status,
                        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
                        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate) {

                if (userId != null || status != null || fromDate != null || toDate != null) {
                        return ResponseEntity.ok(taskService.getTasksWithFilters(userId, status, fromDate, toDate));
                }
                return ResponseEntity.ok(taskService.getAllTasks());
        }

        @GetMapping("/user/{userId}")
        public ResponseEntity<List<TaskResponse>> getTasksByUserId(@PathVariable Long userId) {
                return ResponseEntity.ok(taskService.getTasksByUserId(userId));
        }

        @GetMapping("/overdue")
        public ResponseEntity<List<TaskResponse>> getOverdueTasks() {
                return ResponseEntity.ok(taskService.getOverdueTasks());
        }

        @PutMapping("/{id}")
        public ResponseEntity<TaskResponse> updateTask(@PathVariable Long id,
                        @Valid @RequestBody TaskUpdateRequest request) {
                return ResponseEntity.ok(taskService.updateTask(id, request));
        }

        @PatchMapping("/{id}")
        public ResponseEntity<TaskResponse> partialUpdateTask(@PathVariable Long id,
                        @RequestBody TaskUpdateRequest request) {
                return ResponseEntity.ok(taskService.updateTask(id, request));
        }

        @PatchMapping("/{id}/status")
        public ResponseEntity<TaskResponse> updateTaskStatus(@PathVariable Long id,
                        @Valid @RequestBody TaskStatusUpdateRequest request) {
                return ResponseEntity.ok(taskService.updateTaskStatus(id, request));
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteTask(@PathVariable Long id) {
                taskService.deleteTask(id);
                return ResponseEntity.noContent().build();
        }
}
