package com.example.taskmanagement.dto.task;

import com.example.taskmanagement.entity.TaskStatus;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * DTO for creating a new task.
 * 
 * This DTO demonstrates:
 * - Required fields with @NotBlank/@NotNull
 * - Optional fields (status, description)
 * - Date validation with @Future
 * - Relationship references by ID (userId)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskCreateRequest {

    /**
     * Task title - required.
     */
    @NotBlank(message = "Title is required")
    @Size(min = 3, max = 200, message = "Title must be between 3 and 200 characters")
    private String title;

    /**
     * Task description - optional.
     * No @NotBlank because it's optional.
     */
    @Size(max = 5000, message = "Description must not exceed 5000 characters")
    private String description;

    /**
     * Initial status - optional.
     * If not provided, defaults to PENDING (handled in service layer).
     */
    private TaskStatus status;

    /**
     * Due date - optional.
     * 
     * @Future ensures the date is in the future (if provided).
     * 
     *         Note: @Future validation might need adjustment depending on business
     *         rules.
     *         Some tasks might have a due date of today.
     */
    @Future(message = "Due date must be in the future")
    private LocalDate dueDate;

    /**
     * ID of the user to assign this task to - required.
     * 
     * We pass the user ID, not the full user object.
     * The service layer will:
     * 1. Validate that this user exists
     * 2. Fetch the User entity
     * 3. Set the relationship
     */
    @NotNull(message = "User ID is required")
    private Long userId;
}
