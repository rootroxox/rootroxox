package com.example.taskmanagement.dto.task;

import com.example.taskmanagement.entity.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DTO for task responses.
 * 
 * Includes embedded user info to avoid clients having to make separate
 * requests.
 * We include only essential user fields, not the entire user object.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskResponse {

    /**
     * Task unique identifier.
     */
    private Long id;

    /**
     * Task title.
     */
    private String title;

    /**
     * Task description.
     */
    private String description;

    /**
     * Current status of the task.
     */
    private TaskStatus status;

    /**
     * Due date for the task.
     */
    private LocalDate dueDate;

    /**
     * When the task was created.
     */
    private LocalDateTime createdAt;

    /**
     * When the task was last updated.
     */
    private LocalDateTime updatedAt;

    /**
     * ID of the assigned user.
     */
    private Long userId;

    /**
     * Name of the assigned user.
     * Embedded here so clients don't need a separate request.
     */
    private String userName;

    /**
     * Computed field: Is the task overdue?
     * True if dueDate is past and status is not COMPLETED or CANCELLED.
     */
    private Boolean overdue;
}
