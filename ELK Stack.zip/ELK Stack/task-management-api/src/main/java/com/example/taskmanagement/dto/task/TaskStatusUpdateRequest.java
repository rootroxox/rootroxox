package com.example.taskmanagement.dto.task;

import com.example.taskmanagement.entity.TaskStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO specifically for updating task status.
 * 
 * WHY A SEPARATE DTO?
 * 
 * For "mark as complete" type operations, it's cleaner to have a dedicated
 * endpoint and DTO rather than using the general update DTO.
 * 
 * This provides:
 * - Clear API semantics (PATCH /tasks/{id}/status)
 * - Better validation (status is required, not optional)
 * - Simpler client code
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskStatusUpdateRequest {

    /**
     * The new status for the task - required.
     */
    @NotNull(message = "Status is required")
    private TaskStatus status;
}
