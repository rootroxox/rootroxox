package com.example.taskmanagement.dto.task;

import com.example.taskmanagement.entity.TaskStatus;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * DTO for updating an existing task.
 * 
 * All fields are optional for partial updates.
 * The service layer will only update fields that are non-null.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskUpdateRequest {

    /**
     * Task title - optional for updates.
     */
    @Size(min = 3, max = 200, message = "Title must be between 3 and 200 characters")
    private String title;

    /**
     * Task description - optional.
     */
    @Size(max = 5000, message = "Description must not exceed 5000 characters")
    private String description;

    /**
     * Task status - optional.
     * Can be used to mark task as COMPLETED, CANCELLED, etc.
     */
    private TaskStatus status;

    /**
     * Due date - optional.
     * 
     * @FutureOrPresent allows today's date (different from create).
     */
    @FutureOrPresent(message = "Due date cannot be in the past")
    private LocalDate dueDate;

    /**
     * User ID to reassign the task - optional.
     * If provided, task will be reassigned to this user.
     */
    private Long userId;
}
