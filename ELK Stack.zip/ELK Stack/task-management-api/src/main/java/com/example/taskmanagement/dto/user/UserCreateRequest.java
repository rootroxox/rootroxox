package com.example.taskmanagement.dto.user;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for creating a new user.
 * 
 * DTOs (Data Transfer Objects) EXPLAINED:
 * 
 * Why use DTOs instead of exposing entities directly?
 * 1. SECURITY: Control what data is exposed/accepted
 * 2. VALIDATION: Add validation rules specific to the use case
 * 3. FLEXIBILITY: Different DTOs for different operations (create vs update)
 * 4. DECOUPLING: API contract is separate from database structure
 * 5. PERFORMANCE: Include only the fields you need
 * 
 * VALIDATION ANNOTATIONS:
 * - @NotBlank: Not null, not empty, not just whitespace
 * - @NotNull: Cannot be null (but can be empty string)
 * - @Size: Min and max length constraints
 * - @Email: Must be a valid email format
 * - @Min/@Max: Numeric range constraints
 * - @Pattern: Must match a regex pattern
 * 
 * These validations are triggered when you use @Valid in the controller.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserCreateRequest {

    /**
     * User's name.
     * - Required (not blank)
     * - Between 2 and 100 characters
     */
    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    /**
     * User's email address.
     * - Required (not blank)
     * - Must be a valid email format
     * - Max 255 characters
     */
    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    @Size(max = 255, message = "Email must not exceed 255 characters")
    private String email;
}
