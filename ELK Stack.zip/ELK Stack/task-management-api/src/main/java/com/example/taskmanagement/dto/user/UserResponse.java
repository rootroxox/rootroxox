package com.example.taskmanagement.dto.user;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO for user responses.
 * 
 * RESPONSE DTOs:
 * 
 * Response DTOs typically:
 * - Don't have validation annotations (validation is for input)
 * - Include computed/derived fields if needed
 * - Exclude sensitive data (passwords, internal IDs, etc.)
 * - Include timestamps and other metadata
 * 
 * Notice we DON'T include:
 * - List of tasks (to avoid circular references and performance issues)
 * - Any internal fields not meant for the client
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserResponse {

    /**
     * Unique identifier for the user.
     */
    private Long id;

    /**
     * User's display name.
     */
    private String name;

    /**
     * User's email address.
     */
    private String email;

    /**
     * When the user was created.
     */
    private LocalDateTime createdAt;

    /**
     * When the user was last updated.
     */
    private LocalDateTime updatedAt;

    /**
     * Number of tasks assigned to this user.
     * This is a computed field - we don't store it, we calculate it.
     */
    private Integer taskCount;
}
