package com.example.taskmanagement.dto.user;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for updating an existing user.
 * 
 * UPDATE DTOs vs CREATE DTOs:
 * 
 * For updates, fields are typically optional (not @NotBlank) because
 * the user might only want to update some fields, not all.
 * 
 * This is called "partial update" or "PATCH semantics".
 * 
 * The service layer will:
 * 1. Fetch the existing entity
 * 2. Only update fields that are provided (not null)
 * 3. Keep existing values for fields that are null
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserUpdateRequest {

    /**
     * User's name - optional for updates.
     * If provided, must be between 2 and 100 characters.
     */
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    /**
     * User's email - optional for updates.
     * If provided, must be a valid email format.
     */
    @Email(message = "Email must be a valid email address")
    @Size(max = 255, message = "Email must not exceed 255 characters")
    private String email;
}
