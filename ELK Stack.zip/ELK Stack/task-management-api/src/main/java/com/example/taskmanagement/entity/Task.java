package com.example.taskmanagement.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Task entity representing a task in the system.
 * 
 * RELATIONSHIP EXPLAINED:
 * 
 * @ManyToOne - Many tasks can belong to one user
 * @JoinColumn - Specifies the foreign key column in this table
 * 
 *             The relationship is:
 *             - User (1) <---> (*) Task
 *             - The Task table has a 'user_id' column referencing the User
 *             table
 */
@Entity
@Table(name = "tasks", indexes = {
        // Creating indexes for commonly queried fields improves performance
        @Index(name = "idx_task_status", columnList = "status"),
        @Index(name = "idx_task_due_date", columnList = "due_date"),
        @Index(name = "idx_task_user_id", columnList = "user_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Short title for the task.
     */
    @Column(nullable = false, length = 200)
    private String title;

    /**
     * Detailed description of the task.
     * Using TEXT type for longer content.
     */
    @Column(columnDefinition = "TEXT")
    private String description;

    /**
     * Current status of the task.
     * 
     * @Enumerated(STRING) - Stores the enum name as a string in the database
     * (e.g., "PENDING", "COMPLETED")
     * Using STRING instead of ORDINAL because:
     * - More readable in the database
     * - Safe if enum order changes
     * - Easier debugging
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private TaskStatus status = TaskStatus.PENDING;

    /**
     * Due date for the task.
     * Using LocalDate (not LocalDateTime) since we only need the date part.
     */
    @Column(name = "due_date")
    private LocalDate dueDate;

    /**
     * When the task was created.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * When the task was last modified.
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * The user who owns this task.
     * 
     * @ManyToOne - This side of the relationship
     *            fetch = LAZY - User is loaded only when explicitly accessed
     * @JoinColumn - Defines the foreign key column
     * 
     *             NOTE: We don't use optional = false here because tasks might be
     *             created
     *             without an assigned user initially.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    /**
     * Lifecycle callback - sets timestamps on create.
     */
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) {
            status = TaskStatus.PENDING;
        }
    }

    /**
     * Lifecycle callback - updates timestamp on update.
     */
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
