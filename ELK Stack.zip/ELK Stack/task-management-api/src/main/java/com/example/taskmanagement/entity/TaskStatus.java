package com.example.taskmanagement.entity;

/**
 * Enum representing the possible statuses of a Task.
 * 
 * Using an enum instead of a String provides:
 * - Type safety: Only valid statuses can be assigned
 * - IDE support: Autocomplete and refactoring
 * - Documentation: Self-documenting valid values
 * 
 * JPA will store this as a String in the database (see @Enumerated annotation
 * in Task entity)
 */
public enum TaskStatus {

    /**
     * Task has been created but work hasn't started
     */
    PENDING,

    /**
     * Task is currently being worked on
     */
    IN_PROGRESS,

    /**
     * Task has been completed successfully
     */
    COMPLETED,

    /**
     * Task was cancelled and won't be completed
     */
    CANCELLED
}
