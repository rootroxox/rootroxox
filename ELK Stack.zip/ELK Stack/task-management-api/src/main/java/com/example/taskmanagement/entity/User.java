package com.example.taskmanagement.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * User entity representing a user in the system.
 * 
 * KEY JPA ANNOTATIONS EXPLAINED:
 * 
 * @Entity - Marks this class as a JPA entity (maps to a database table)
 * @Table - Specifies the table name (defaults to class name if omitted)
 * @Id - Marks the primary key field
 * @GeneratedValue - Tells JPA how to generate the primary key
 *                 IDENTITY strategy uses database auto-increment
 * @Column - Customizes column properties (name, nullable, unique, length)
 * 
 *         LOMBOK ANNOTATIONS:
 * @Data - Generates getters, setters, toString, equals, hashCode
 * @NoArgsConstructor - Generates no-args constructor (required by JPA)
 * @AllArgsConstructor - Generates constructor with all fields
 * @Builder - Enables builder pattern for object creation
 */
@Entity
@Table(name = "users") // "user" is a reserved word in some databases
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    /**
     * Primary key with auto-generated values.
     * Using Long instead of long for nullable support.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * User's display name.
     * nullable = false means this column cannot be null in the database.
     */
    @Column(nullable = false, length = 100)
    private String name;

    /**
     * User's email address.
     * unique = true creates a unique constraint in the database.
     */
    @Column(nullable = false, unique = true, length = 255)
    private String email;

    /**
     * Timestamp when the user was created.
     * updatable = false means this field won't be updated after initial insert.
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Timestamp when the user was last updated.
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * One-to-Many relationship with Task.
     * 
     * mappedBy = "user" - The 'user' field in Task entity owns the relationship
     * cascade = ALL - Operations on User cascade to associated Tasks
     * orphanRemoval = true - Removing a task from the list deletes it from DB
     * fetch = LAZY - Tasks are loaded only when explicitly accessed (performance)
     * 
     * We use @Builder.Default to initialize the list when using the builder.
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Task> tasks = new ArrayList<>();

    /**
     * JPA lifecycle callback - called before INSERT.
     * Automatically sets createdAt and updatedAt timestamps.
     */
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    /**
     * JPA lifecycle callback - called before UPDATE.
     * Automatically updates the updatedAt timestamp.
     */
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
