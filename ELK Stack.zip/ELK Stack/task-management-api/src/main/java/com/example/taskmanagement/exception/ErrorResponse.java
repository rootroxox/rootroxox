package com.example.taskmanagement.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Unified error response format for all API errors.
 * 
 * WHY A UNIFIED ERROR RESPONSE?
 * 
 * Consistency matters for API consumers. When they receive an error,
 * they should always get the same structure, regardless of:
 * - Whether it's a validation error
 * - Whether it's a not-found error
 * - Whether it's an internal server error
 * 
 * This class defines that consistent structure.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse {

    /**
     * When the error occurred (ISO-8601 format in JSON).
     */
    private LocalDateTime timestamp;

    /**
     * HTTP status code (e.g., 400, 404, 500).
     */
    private int status;

    /**
     * Short error code for programmatic handling.
     * Examples: "NOT_FOUND", "VALIDATION_ERROR", "DUPLICATE_RESOURCE"
     */
    private String errorCode;

    /**
     * Human-readable error message.
     */
    private String message;

    /**
     * More detailed description or context.
     */
    private String details;

    /**
     * The API path that was called.
     */
    private String path;

    /**
     * For validation errors: list of field-specific errors.
     */
    private List<FieldError> fieldErrors;

    /**
     * Correlation ID for tracking this request in logs.
     * This is KEY for ELK integration - you can search logs by this ID.
     */
    private String correlationId;

    /**
     * Inner class for field-level validation errors.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FieldError {
        /**
         * The field that has an error (e.g., "email").
         */
        private String field;

        /**
         * The rejected value.
         */
        private Object rejectedValue;

        /**
         * Why this value was rejected.
         */
        private String message;
    }
}
