package com.example.taskmanagement.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a requested resource is not found.
 * 
 * CUSTOM EXCEPTIONS EXPLAINED:
 * 
 * Why create custom exceptions?
 * 1. Clear semantics: The exception name tells you what went wrong
 * 2. HTTP mapping: @ResponseStatus automatically sets the HTTP status code
 * 3. Centralized handling: GlobalExceptionHandler can catch specific types
 * 4. Business context: You can include domain-specific information
 * 
 * @ResponseStatus maps this exception to HTTP 404 Not Found
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

    private final String resourceName;
    private final String fieldName;
    private final Object fieldValue;

    /**
     * Create a new ResourceNotFoundException.
     * 
     * @param resourceName The type of resource (e.g., "User", "Task")
     * @param fieldName    The field used to search (e.g., "id")
     * @param fieldValue   The value that was not found
     */
    public ResourceNotFoundException(String resourceName, String fieldName, Object fieldValue) {
        super(String.format("%s not found with %s: '%s'", resourceName, fieldName, fieldValue));
        this.resourceName = resourceName;
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
    }

    /**
     * Simpler constructor with just a message.
     */
    public ResourceNotFoundException(String message) {
        super(message);
        this.resourceName = null;
        this.fieldName = null;
        this.fieldValue = null;
    }

    public String getResourceName() {
        return resourceName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public Object getFieldValue() {
        return fieldValue;
    }
}
