package com.example.taskmanagement.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.logstash.logback.argument.StructuredArgument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static net.logstash.logback.argument.StructuredArguments.kv;

/**
 * Request/Response logging filter.
 * 
 * LOG ORDER:
 * 1. [REQUEST] - Logged FIRST when request arrives
 * 2. EXECUTION logs - During service processing
 * 3. [RESPONSE] - Logged LAST after processing completes
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestResponseLoggingFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(RequestResponseLoggingFilter.class);
    private static final int MAX_BODY = 1000;

    // Thread-local sequence counter for each request
    private static final ThreadLocal<AtomicInteger> SEQ_COUNTER = new ThreadLocal<>();

    /**
     * Get the next sequence number as a StructuredArgument.
     */
    public static StructuredArgument nextSeq() {
        AtomicInteger counter = SEQ_COUNTER.get();
        if (counter != null) {
            return kv("seq", counter.incrementAndGet());
        }
        return kv("seq", 0);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        // Skip actuator
        if (request.getRequestURI().startsWith("/actuator")) {
            filterChain.doFilter(request, response);
            return;
        }

        // Initialize correlation ID and sequence counter
        String correlationId = UUID.randomUUID().toString().substring(0, 8);
        MDC.put("correlationId", correlationId);
        SEQ_COUNTER.set(new AtomicInteger(0));
        response.setHeader("X-Correlation-ID", correlationId);

        ContentCachingRequestWrapper req = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper res = new ContentCachingResponseWrapper(response);

        String method = request.getMethod();
        String uri = request.getRequestURI();

        // ========== LOG REQUEST FIRST ==========
        log.info("[REQUEST] {} {}",
                method, uri,
                nextSeq(), kv("logCategory", "API"));

        long start = System.currentTimeMillis();

        try {
            // ========== EXECUTION HAPPENS HERE ==========
            filterChain.doFilter(req, res);
        } finally {
            long duration = System.currentTimeMillis() - start;

            // ========== LOG RESPONSE LAST ==========
            String resBody = getBody(res.getContentAsByteArray());
            int status = res.getStatus();

            if (status >= 400) {
                log.warn("[RESPONSE] {} {} | Status: {} | Duration: {}ms | Body: {}",
                        method, uri, status, duration, resBody != null ? resBody : "(empty)",
                        nextSeq(), kv("logCategory", "API"));
            } else {
                log.info("[RESPONSE] {} {} | Status: {} | Duration: {}ms | Body: {}",
                        method, uri, status, duration, resBody != null ? resBody : "(empty)",
                        nextSeq(), kv("logCategory", "API"));
            }

            // Cleanup
            MDC.remove("correlationId");
            SEQ_COUNTER.remove();

            res.copyBodyToResponse();
        }
    }

    private String getBody(byte[] content) {
        if (content == null || content.length == 0)
            return null;
        int len = Math.min(content.length, MAX_BODY);
        return new String(content, 0, len, StandardCharsets.UTF_8);
    }
}
