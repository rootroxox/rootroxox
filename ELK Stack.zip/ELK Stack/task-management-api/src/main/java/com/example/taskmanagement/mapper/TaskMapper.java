package com.example.taskmanagement.mapper;

import com.example.taskmanagement.dto.task.TaskCreateRequest;
import com.example.taskmanagement.dto.task.TaskResponse;
import com.example.taskmanagement.dto.task.TaskUpdateRequest;
import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.entity.TaskStatus;
import com.example.taskmanagement.entity.User;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Manual mapper for Task entity <-> DTO conversions.
 * 
 * This mapper demonstrates:
 * - Handling relationships (user reference)
 * - Computed fields (overdue check)
 * - Partial updates for PATCH operations
 */
@Component
public class TaskMapper {

    /**
     * Convert a create request to a new Task entity.
     * 
     * @param request The create request DTO
     * @param user    The User entity to associate (fetched separately)
     * @return A new Task entity (not persisted yet)
     */
    public Task toEntity(TaskCreateRequest request, User user) {
        if (request == null) {
            return null;
        }

        return Task.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                // Default to PENDING if not specified
                .status(request.getStatus() != null ? request.getStatus() : TaskStatus.PENDING)
                .dueDate(request.getDueDate())
                .user(user) // Set the relationship
                .build();

        // Note: id and timestamps are handled by JPA
    }

    /**
     * Convert a Task entity to a response DTO.
     * 
     * @param task The task entity
     * @return Response DTO for the API
     */
    public TaskResponse toResponse(Task task) {
        if (task == null) {
            return null;
        }

        // Determine if the task is overdue
        boolean isOverdue = calculateOverdue(task);

        TaskResponse.TaskResponseBuilder builder = TaskResponse.builder()
                .id(task.getId())
                .title(task.getTitle())
                .description(task.getDescription())
                .status(task.getStatus())
                .dueDate(task.getDueDate())
                .createdAt(task.getCreatedAt())
                .updatedAt(task.getUpdatedAt())
                .overdue(isOverdue);

        // Include user info if the relationship is loaded
        if (task.getUser() != null) {
            builder.userId(task.getUser().getId())
                    .userName(task.getUser().getName());
        }

        return builder.build();
    }

    /**
     * Update an existing Task entity with data from an update request.
     * Only updates fields that are non-null.
     * 
     * @param task    The existing task entity
     * @param request The update request DTO
     * @param newUser New user to assign (if userId was provided and resolved)
     */
    public void updateEntity(Task task, TaskUpdateRequest request, User newUser) {
        if (task == null || request == null) {
            return;
        }

        if (request.getTitle() != null) {
            task.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            task.setDescription(request.getDescription());
        }
        if (request.getStatus() != null) {
            task.setStatus(request.getStatus());
        }
        if (request.getDueDate() != null) {
            task.setDueDate(request.getDueDate());
        }
        if (newUser != null) {
            task.setUser(newUser);
        }

        // updatedAt is handled by @PreUpdate
    }

    /**
     * Calculate if a task is overdue.
     * 
     * A task is overdue if:
     * - It has a due date
     * - The due date is in the past
     * - The status is NOT completed or cancelled
     * 
     * @param task The task to check
     * @return true if overdue
     */
    private boolean calculateOverdue(Task task) {
        if (task.getDueDate() == null) {
            return false;
        }

        if (task.getStatus() == TaskStatus.COMPLETED ||
                task.getStatus() == TaskStatus.CANCELLED) {
            return false;
        }

        return task.getDueDate().isBefore(LocalDate.now());
    }
}
