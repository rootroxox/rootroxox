package com.example.taskmanagement.repository;

import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.entity.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository for Task entity.
 * 
 * This repository demonstrates:
 * 1. Method name query derivation (simple approach)
 * 2. @Query annotation with JPQL (more control)
 * 3. Native SQL queries (when needed)
 * 
 * QUERY METHODS NAMING CONVENTIONS:
 * - findBy... - Returns result(s)
 * - countBy... - Returns count
 * - existsBy... - Returns boolean
 * - deleteBy... - Deletes matching records
 * 
 * KEYWORDS:
 * - And, Or - Combine conditions
 * - OrderBy - Sort results
 * - Between - Range queries
 * - LessThan, GreaterThan - Comparisons
 * - Like, Containing - Pattern matching
 * - IsNull, IsNotNull - Null checks
 */
@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    // ==========================================
    // Simple Query Methods (derived from name)
    // ==========================================

    /**
     * Find all tasks for a specific user.
     * Generated query: SELECT * FROM tasks WHERE user_id = ?
     */
    List<Task> findByUserId(Long userId);

    /**
     * Find all tasks with a specific status.
     * Generated query: SELECT * FROM tasks WHERE status = ?
     */
    List<Task> findByStatus(TaskStatus status);

    /**
     * Find tasks for a user with a specific status.
     * Combines two conditions with AND.
     */
    List<Task> findByUserIdAndStatus(Long userId, TaskStatus status);

    /**
     * Find tasks due before a certain date.
     * Useful for finding overdue tasks.
     */
    List<Task> findByDueDateBefore(LocalDate date);

    /**
     * Find tasks due on a specific date.
     */
    List<Task> findByDueDate(LocalDate date);

    /**
     * Find tasks due between two dates.
     */
    List<Task> findByDueDateBetween(LocalDate startDate, LocalDate endDate);

    /**
     * Find tasks with title containing a search term (case-insensitive).
     */
    List<Task> findByTitleContainingIgnoreCase(String title);

    // ==========================================
    // JPQL Queries (more control)
    // ==========================================

    /**
     * Find overdue tasks that are not completed.
     * 
     * JPQL (Java Persistence Query Language) works with entities and fields,
     * not tables and columns. This makes queries database-independent.
     */
    @Query("SELECT t FROM Task t WHERE t.dueDate < :today AND t.status NOT IN (:completedStatuses)")
    List<Task> findOverdueTasks(
            @Param("today") LocalDate today,
            @Param("completedStatuses") List<TaskStatus> completedStatuses);

    /**
     * Find tasks for a user with filtering options.
     * 
     * This query demonstrates optional parameters using COALESCE/null checks.
     * If a parameter is null, that condition is ignored.
     */
    @Query("SELECT t FROM Task t WHERE t.user.id = :userId " +
            "AND (:status IS NULL OR t.status = :status) " +
            "AND (:fromDate IS NULL OR t.dueDate >= :fromDate) " +
            "AND (:toDate IS NULL OR t.dueDate <= :toDate) " +
            "ORDER BY t.dueDate ASC NULLS LAST")
    List<Task> findTasksWithFilters(
            @Param("userId") Long userId,
            @Param("status") TaskStatus status,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate);

    /**
     * Count tasks by status for a specific user.
     * Useful for dashboard statistics.
     */
    @Query("SELECT COUNT(t) FROM Task t WHERE t.user.id = :userId AND t.status = :status")
    long countByUserIdAndStatus(@Param("userId") Long userId, @Param("status") TaskStatus status);

    // ==========================================
    // Native SQL Query (when JPQL isn't enough)
    // ==========================================

    /**
     * Example of a native SQL query.
     * Use sparingly - it ties you to a specific database.
     * 
     * nativeQuery = true tells Spring to use SQL instead of JPQL.
     */
    @Query(value = "SELECT * FROM tasks WHERE EXTRACT(MONTH FROM due_date) = :month " +
            "AND EXTRACT(YEAR FROM due_date) = :year", nativeQuery = true)
    List<Task> findTasksDueInMonth(@Param("month") int month, @Param("year") int year);
}
