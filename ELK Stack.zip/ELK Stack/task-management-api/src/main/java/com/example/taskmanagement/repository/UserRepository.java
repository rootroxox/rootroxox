package com.example.taskmanagement.repository;

import com.example.taskmanagement.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for User entity.
 * 
 * SPRING DATA JPA EXPLAINED:
 * 
 * By extending JpaRepository, we get these methods FOR FREE:
 * - save(entity) - Insert or update
 * - findById(id) - Find by primary key
 * - findAll() - Get all records
 * - deleteById(id) - Delete by primary key
 * - count() - Count all records
 * - existsById(id) - Check if exists
 * 
 * JpaRepository<User, Long>:
 * - User = The entity type
 * - Long = The type of the primary key
 * 
 * @Repository is optional here (Spring Data auto-detects), but good for
 *             clarity.
 * 
 *             QUERY CREATION BY METHOD NAME:
 *             Spring Data creates queries from method names automatically!
 *             - findByEmail -> SELECT * FROM users WHERE email = ?
 *             - findByName -> SELECT * FROM users WHERE name = ?
 *             - findByNameContaining -> SELECT * FROM users WHERE name LIKE %?%
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Find a user by their email address.
     * Spring Data automatically generates the query from the method name.
     * 
     * @param email The email to search for
     * @return Optional containing the user if found, empty otherwise
     */
    Optional<User> findByEmail(String email);

    /**
     * Check if a user with the given email exists.
     * Useful for validation before creating a new user.
     * 
     * @param email The email to check
     * @return true if a user with this email exists
     */
    boolean existsByEmail(String email);
}
