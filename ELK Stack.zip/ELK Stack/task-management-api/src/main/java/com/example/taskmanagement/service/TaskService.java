package com.example.taskmanagement.service;

import com.example.taskmanagement.dto.task.TaskCreateRequest;
import com.example.taskmanagement.dto.task.TaskResponse;
import com.example.taskmanagement.dto.task.TaskStatusUpdateRequest;
import com.example.taskmanagement.dto.task.TaskUpdateRequest;
import com.example.taskmanagement.entity.TaskStatus;

import java.time.LocalDate;
import java.util.List;

/**
 * Service interface for Task operations.
 */
public interface TaskService {

    /**
     * Create a new task.
     * 
     * @param request The task data
     * @return The created task
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if
     *                                                                        user
     *                                                                        not
     *                                                                        found
     */
    TaskResponse createTask(TaskCreateRequest request);

    /**
     * Get a task by ID.
     * 
     * @param id The task ID
     * @return The task
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    TaskResponse getTaskById(Long id);

    /**
     * Get all tasks.
     * 
     * @return List of all tasks
     */
    List<TaskResponse> getAllTasks();

    /**
     * Get all tasks for a specific user.
     * 
     * @param userId The user ID
     * @return List of tasks
     */
    List<TaskResponse> getTasksByUserId(Long userId);

    /**
     * Get tasks with optional filters.
     * 
     * @param userId   Filter by user (optional)
     * @param status   Filter by status (optional)
     * @param fromDate Filter by due date from (optional)
     * @param toDate   Filter by due date to (optional)
     * @return Filtered list of tasks
     */
    List<TaskResponse> getTasksWithFilters(Long userId, TaskStatus status,
            LocalDate fromDate, LocalDate toDate);

    /**
     * Get overdue tasks.
     * 
     * @return List of overdue tasks
     */
    List<TaskResponse> getOverdueTasks();

    /**
     * Update an existing task.
     * 
     * @param id      The task ID
     * @param request The update data
     * @return The updated task
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    TaskResponse updateTask(Long id, TaskUpdateRequest request);

    /**
     * Update only the status of a task.
     * Useful for quick status changes (e.g., mark as complete).
     * 
     * @param id      The task ID
     * @param request The new status
     * @return The updated task
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    TaskResponse updateTaskStatus(Long id, TaskStatusUpdateRequest request);

    /**
     * Delete a task.
     * 
     * @param id The task ID
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    void deleteTask(Long id);
}
