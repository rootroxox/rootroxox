package com.example.taskmanagement.service;

import com.example.taskmanagement.dto.task.TaskCreateRequest;
import com.example.taskmanagement.dto.task.TaskResponse;
import com.example.taskmanagement.dto.task.TaskStatusUpdateRequest;
import com.example.taskmanagement.dto.task.TaskUpdateRequest;
import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.entity.TaskStatus;
import com.example.taskmanagement.entity.User;
import com.example.taskmanagement.exception.ResourceNotFoundException;
import com.example.taskmanagement.filter.RequestResponseLoggingFilter;
import com.example.taskmanagement.mapper.TaskMapper;
import com.example.taskmanagement.repository.TaskRepository;
import com.example.taskmanagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static net.logstash.logback.argument.StructuredArguments.kv;

/**
 * TaskService with simple, human-readable execution logs.
 */
@Service
public class TaskServiceImpl implements TaskService {

        private static final Logger log = LoggerFactory.getLogger(TaskServiceImpl.class);

        private final TaskRepository taskRepository;
        private final UserRepository userRepository;
        private final TaskMapper taskMapper;

        public TaskServiceImpl(TaskRepository taskRepository, UserRepository userRepository, TaskMapper taskMapper) {
                this.taskRepository = taskRepository;
                this.userRepository = userRepository;
                this.taskMapper = taskMapper;
        }

        // Structured args go AFTER message args
        private void logInfo(String message, Object... args) {
                Object[] allArgs = new Object[args.length + 2];
                System.arraycopy(args, 0, allArgs, 0, args.length);
                allArgs[args.length] = RequestResponseLoggingFilter.nextSeq();
                allArgs[args.length + 1] = kv("logCategory", "EXECUTION");
                log.info(message, allArgs);
        }

        private void logWarn(String message, Object... args) {
                Object[] allArgs = new Object[args.length + 2];
                System.arraycopy(args, 0, allArgs, 0, args.length);
                allArgs[args.length] = RequestResponseLoggingFilter.nextSeq();
                allArgs[args.length + 1] = kv("logCategory", "EXECUTION");
                log.warn(message, allArgs);
        }

        @Override
        @Transactional
        public TaskResponse createTask(TaskCreateRequest request) {
                logInfo("Creating task '{}' for user {}", request.getTitle(), request.getUserId());
                logInfo("Checking if user {} exists...", request.getUserId());

                User user = userRepository.findById(request.getUserId())
                                .orElseThrow(() -> {
                                        logWarn("User {} not found - cannot create task", request.getUserId());
                                        return new ResourceNotFoundException("User", "id", request.getUserId());
                                });

                logInfo("User found: {}", user.getName());

                Task task = taskMapper.toEntity(request, user);
                Task savedTask = taskRepository.save(task);

                logInfo("Task created with ID: {}", savedTask.getId());

                return taskMapper.toResponse(savedTask);
        }

        @Override
        @Transactional(readOnly = true)
        public TaskResponse getTaskById(Long id) {
                logInfo("Fetching task with ID: {}", id);

                Task task = taskRepository.findById(id)
                                .orElseThrow(() -> {
                                        logWarn("Task {} not found", id);
                                        return new ResourceNotFoundException("Task", "id", id);
                                });

                logInfo("Found task: '{}'", task.getTitle());
                return taskMapper.toResponse(task);
        }

        @Override
        @Transactional(readOnly = true)
        public List<TaskResponse> getAllTasks() {
                logInfo("Fetching all tasks...");

                List<Task> tasks = taskRepository.findAll();

                logInfo("Found {} tasks", tasks.size());
                return tasks.stream().map(taskMapper::toResponse).collect(Collectors.toList());
        }

        @Override
        @Transactional(readOnly = true)
        public List<TaskResponse> getTasksByUserId(Long userId) {
                logInfo("Fetching tasks for user {}", userId);

                if (!userRepository.existsById(userId)) {
                        logWarn("User {} not found", userId);
                        throw new ResourceNotFoundException("User", "id", userId);
                }

                List<Task> tasks = taskRepository.findByUserId(userId);
                logInfo("Found {} tasks for user {}", tasks.size(), userId);

                return tasks.stream().map(taskMapper::toResponse).collect(Collectors.toList());
        }

        @Override
        @Transactional(readOnly = true)
        public List<TaskResponse> getOverdueTasks() {
                logInfo("Fetching overdue tasks...");

                List<TaskStatus> completedStatuses = List.of(TaskStatus.COMPLETED, TaskStatus.CANCELLED);
                List<Task> tasks = taskRepository.findOverdueTasks(LocalDate.now(), completedStatuses);

                logInfo("Found {} overdue tasks", tasks.size());
                return tasks.stream().map(taskMapper::toResponse).collect(Collectors.toList());
        }

        @Override
        @Transactional(readOnly = true)
        public List<TaskResponse> getTasksWithFilters(Long userId, TaskStatus status, LocalDate fromDate,
                        LocalDate toDate) {
                logInfo("Fetching tasks with filters...");

                List<Task> tasks = taskRepository.findTasksWithFilters(userId, status, fromDate, toDate);

                logInfo("Found {} tasks matching filters", tasks.size());
                return tasks.stream().map(taskMapper::toResponse).collect(Collectors.toList());
        }

        @Override
        @Transactional
        public TaskResponse updateTask(Long id, TaskUpdateRequest request) {
                logInfo("Updating task {}", id);

                Task task = taskRepository.findById(id)
                                .orElseThrow(() -> {
                                        logWarn("Task {} not found for update", id);
                                        return new ResourceNotFoundException("Task", "id", id);
                                });

                taskMapper.updateEntity(task, request, null);
                Task updatedTask = taskRepository.save(task);

                logInfo("Task {} updated successfully", id);
                return taskMapper.toResponse(updatedTask);
        }

        @Override
        @Transactional
        public TaskResponse updateTaskStatus(Long id, TaskStatusUpdateRequest request) {
                logInfo("Updating task {} status to {}", id, request.getStatus());

                Task task = taskRepository.findById(id)
                                .orElseThrow(() -> {
                                        logWarn("Task {} not found for status update", id);
                                        return new ResourceNotFoundException("Task", "id", id);
                                });

                TaskStatus oldStatus = task.getStatus();
                task.setStatus(request.getStatus());
                taskRepository.save(task);

                logInfo("Task {} status changed: {} -> {}", id, oldStatus, request.getStatus());
                return taskMapper.toResponse(task);
        }

        @Override
        @Transactional
        public void deleteTask(Long id) {
                logInfo("Deleting task {}", id);

                if (!taskRepository.existsById(id)) {
                        logWarn("Task {} not found for deletion", id);
                        throw new ResourceNotFoundException("Task", "id", id);
                }

                taskRepository.deleteById(id);
                logInfo("Task {} deleted successfully", id);
        }
}
