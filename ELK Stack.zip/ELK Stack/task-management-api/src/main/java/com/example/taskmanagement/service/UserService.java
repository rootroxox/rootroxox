package com.example.taskmanagement.service;

import com.example.taskmanagement.dto.user.UserCreateRequest;
import com.example.taskmanagement.dto.user.UserResponse;
import com.example.taskmanagement.dto.user.UserUpdateRequest;

import java.util.List;

/**
 * Service interface for User operations.
 * 
 * WHY USE AN INTERFACE?
 * 
 * 1. ABSTRACTION: Controllers depend on the interface, not the implementation
 * 2. TESTABILITY: Easy to mock in unit tests
 * 3. FLEXIBILITY: Can swap implementations (e.g., different data sources)
 * 4. DOCUMENTATION: Interface clearly defines the service contract
 * 5. SPRING AOP: Works better with interfaces for proxying
 * 
 * The implementation (UserServiceImpl) contains the actual business logic.
 */
public interface UserService {

    /**
     * Create a new user.
     * 
     * @param request The user data
     * @return The created user
     * @throws com.example.taskmanagement.exception.DuplicateResourceException if
     *                                                                         email
     *                                                                         exists
     */
    UserResponse createUser(UserCreateRequest request);

    /**
     * Get a user by ID.
     * 
     * @param id The user ID
     * @return The user
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    UserResponse getUserById(Long id);

    /**
     * Get a user by email.
     * 
     * @param email The email address
     * @return The user
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    UserResponse getUserByEmail(String email);

    /**
     * Get all users.
     * 
     * @return List of all users
     */
    List<UserResponse> getAllUsers();

    /**
     * Update an existing user.
     * 
     * @param id      The user ID to update
     * @param request The update data
     * @return The updated user
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException  if
     *                                                                         not
     *                                                                         found
     * @throws com.example.taskmanagement.exception.DuplicateResourceException if
     *                                                                         new
     *                                                                         email
     *                                                                         exists
     */
    UserResponse updateUser(Long id, UserUpdateRequest request);

    /**
     * Delete a user.
     * 
     * @param id The user ID to delete
     * @throws com.example.taskmanagement.exception.ResourceNotFoundException if not
     *                                                                        found
     */
    void deleteUser(Long id);
}
