package com.example.taskmanagement.service;

import com.example.taskmanagement.dto.user.UserCreateRequest;
import com.example.taskmanagement.dto.user.UserResponse;
import com.example.taskmanagement.dto.user.UserUpdateRequest;
import com.example.taskmanagement.entity.User;
import com.example.taskmanagement.exception.DuplicateResourceException;
import com.example.taskmanagement.exception.ResourceNotFoundException;
import com.example.taskmanagement.filter.RequestResponseLoggingFilter;
import com.example.taskmanagement.mapper.UserMapper;
import com.example.taskmanagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static net.logstash.logback.argument.StructuredArguments.kv;

/**
 * UserService with simple, human-readable execution logs.
 */
@Service
public class UserServiceImpl implements UserService {

        private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

        private final UserRepository userRepository;
        private final UserMapper userMapper;

        public UserServiceImpl(UserRepository userRepository, UserMapper userMapper) {
                this.userRepository = userRepository;
                this.userMapper = userMapper;
        }

        // Structured args go AFTER message args
        private void logInfo(String message, Object... args) {
                Object[] allArgs = new Object[args.length + 2];
                System.arraycopy(args, 0, allArgs, 0, args.length);
                allArgs[args.length] = RequestResponseLoggingFilter.nextSeq();
                allArgs[args.length + 1] = kv("logCategory", "EXECUTION");
                log.info(message, allArgs);
        }

        private void logWarn(String message, Object... args) {
                Object[] allArgs = new Object[args.length + 2];
                System.arraycopy(args, 0, allArgs, 0, args.length);
                allArgs[args.length] = RequestResponseLoggingFilter.nextSeq();
                allArgs[args.length + 1] = kv("logCategory", "EXECUTION");
                log.warn(message, allArgs);
        }

        @Override
        @Transactional
        public UserResponse createUser(UserCreateRequest request) {
                logInfo("Creating user with email: {}", request.getEmail());
                logInfo("Checking if email '{}' already exists...", request.getEmail());

                if (userRepository.existsByEmail(request.getEmail())) {
                        logWarn("Email '{}' already exists - cannot create user", request.getEmail());
                        throw new DuplicateResourceException("User", "email", request.getEmail());
                }

                logInfo("Email is available, creating user...");

                User user = userMapper.toEntity(request);
                User savedUser = userRepository.save(user);

                logInfo("User created successfully with ID: {}", savedUser.getId());

                return userMapper.toResponse(savedUser);
        }

        @Override
        @Transactional(readOnly = true)
        public UserResponse getUserById(Long id) {
                logInfo("Fetching user with ID: {}", id);

                User user = userRepository.findById(id)
                                .orElseThrow(() -> {
                                        logWarn("User with ID {} not found", id);
                                        return new ResourceNotFoundException("User", "id", id);
                                });

                logInfo("Found user: {}", user.getName());
                return userMapper.toResponse(user);
        }

        @Override
        @Transactional(readOnly = true)
        public UserResponse getUserByEmail(String email) {
                logInfo("Fetching user with email: {}", email);

                User user = userRepository.findByEmail(email)
                                .orElseThrow(() -> {
                                        logWarn("User with email '{}' not found", email);
                                        return new ResourceNotFoundException("User", "email", email);
                                });

                logInfo("Found user: {}", user.getName());
                return userMapper.toResponse(user);
        }

        @Override
        @Transactional(readOnly = true)
        public List<UserResponse> getAllUsers() {
                logInfo("Fetching all users...");

                List<User> users = userRepository.findAll();

                logInfo("Found {} users", users.size());

                return users.stream()
                                .map(userMapper::toResponse)
                                .collect(Collectors.toList());
        }

        @Override
        @Transactional
        public UserResponse updateUser(Long id, UserUpdateRequest request) {
                logInfo("Updating user with ID: {}", id);

                User user = userRepository.findById(id)
                                .orElseThrow(() -> {
                                        logWarn("User with ID {} not found for update", id);
                                        return new ResourceNotFoundException("User", "id", id);
                                });

                if (request.getEmail() != null && !request.getEmail().equals(user.getEmail())) {
                        logInfo("Email change requested, checking if '{}' is available...", request.getEmail());

                        if (userRepository.existsByEmail(request.getEmail())) {
                                logWarn("Email '{}' already taken by another user", request.getEmail());
                                throw new DuplicateResourceException("User", "email", request.getEmail());
                        }
                }

                userMapper.updateEntity(user, request);
                User updatedUser = userRepository.save(user);

                logInfo("User {} updated successfully", updatedUser.getId());

                return userMapper.toResponse(updatedUser);
        }

        @Override
        @Transactional
        public void deleteUser(Long id) {
                logInfo("Deleting user with ID: {}", id);

                if (!userRepository.existsById(id)) {
                        logWarn("User with ID {} not found for deletion", id);
                        throw new ResourceNotFoundException("User", "id", id);
                }

                userRepository.deleteById(id);
                logInfo("User {} deleted successfully", id);
        }
}
